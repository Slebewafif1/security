<?php
$telegram_id = "6156805101";
$id_bot = "5426519917:AAE7UgZ-5pwvt4X_EtE1q0AusYHC1KkpRjI";
?>
